-- phpMyAdmin SQL Dump
-- version 4.6.6deb4
-- https://www.phpmyadmin.net/
--
-- Client :  localhost:3306
-- Généré le :  Lun 11 Février 2019 à 17:10
-- Version du serveur :  10.1.37-MariaDB-0+deb9u1
-- Version de PHP :  7.2.14-1+0~20190113100742.14+stretch~1.gbpd83c69

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `ECF-database`
--

-- --------------------------------------------------------

--
-- Structure de la table `family_instrument`
--

CREATE TABLE `family_instrument` (
  `id` int(11) NOT NULL,
  `family_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `mark`
--

CREATE TABLE `mark` (
  `id` int(11) NOT NULL,
  `mark_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migration_versions`
--

CREATE TABLE `migration_versions` (
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `migration_versions`
--

INSERT INTO `migration_versions` (`version`) VALUES
('20190205130417');

-- --------------------------------------------------------

--
-- Structure de la table `spare_part`
--

CREATE TABLE `spare_part` (
  `id` int(11) NOT NULL,
  `piece_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `spare_part_type_instrument`
--

CREATE TABLE `spare_part_type_instrument` (
  `spare_part_id` int(11) NOT NULL,
  `type_instrument_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `type_instrument`
--

CREATE TABLE `type_instrument` (
  `id` int(11) NOT NULL,
  `family_instrument_id` int(11) DEFAULT NULL,
  `mark_id` int(11) DEFAULT NULL,
  `instrument_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Index pour les tables exportées
--

--
-- Index pour la table `family_instrument`
--
ALTER TABLE `family_instrument`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_F75BAA22A54DC22` (`family_name`);

--
-- Index pour la table `mark`
--
ALTER TABLE `mark`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_6674F2718B8415E3` (`mark_name`);

--
-- Index pour la table `migration_versions`
--
ALTER TABLE `migration_versions`
  ADD PRIMARY KEY (`version`);

--
-- Index pour la table `spare_part`
--
ALTER TABLE `spare_part`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `spare_part_type_instrument`
--
ALTER TABLE `spare_part_type_instrument`
  ADD PRIMARY KEY (`spare_part_id`,`type_instrument_id`),
  ADD KEY `IDX_BF2EDE1349B7A72` (`spare_part_id`),
  ADD KEY `IDX_BF2EDE137C1CAAA9` (`type_instrument_id`);

--
-- Index pour la table `type_instrument`
--
ALTER TABLE `type_instrument`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_21BCBFF889BCCDAE` (`instrument_name`),
  ADD KEY `IDX_21BCBFF882F88FB0` (`family_instrument_id`),
  ADD KEY `IDX_21BCBFF84290F12B` (`mark_id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `family_instrument`
--
ALTER TABLE `family_instrument`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `mark`
--
ALTER TABLE `mark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `spare_part`
--
ALTER TABLE `spare_part`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `type_instrument`
--
ALTER TABLE `type_instrument`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `spare_part_type_instrument`
--
ALTER TABLE `spare_part_type_instrument`
  ADD CONSTRAINT `FK_BF2EDE1349B7A72` FOREIGN KEY (`spare_part_id`) REFERENCES `spare_part` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_BF2EDE137C1CAAA9` FOREIGN KEY (`type_instrument_id`) REFERENCES `type_instrument` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `type_instrument`
--
ALTER TABLE `type_instrument`
  ADD CONSTRAINT `FK_21BCBFF84290F12B` FOREIGN KEY (`mark_id`) REFERENCES `mark` (`id`),
  ADD CONSTRAINT `FK_21BCBFF882F88FB0` FOREIGN KEY (`family_instrument_id`) REFERENCES `family_instrument` (`id`);
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
